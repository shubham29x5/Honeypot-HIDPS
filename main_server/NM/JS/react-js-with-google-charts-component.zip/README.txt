A Pen created at CodePen.io. You can find this one at https://codepen.io/bestjon/pen/RPXoaW.

 A basic example of a react JS component that updates a google chart.

The getData function can me made into a promise with a ajax call to grab the data.